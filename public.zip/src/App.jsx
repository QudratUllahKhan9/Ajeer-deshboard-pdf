import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import QRCodeStyling from 'qr-code-styling'
import { API, saveRecord, updateRecord, getRecord, listRecords, getSettings, setDomain, nowId } from './api.js'
import './App.css'

/* ============ QR look — same as approved design: square modules,
   square eyes, navy #0B1736 on white, no logo, no frame, 4-module quiet zone.
   Payload = backend URL + id  →  https://api.yourdomain.com/v/abc12345        */



const QR_LOOK = {
  type: 'svg',
  margin: 3,

  qrOptions: {
    errorCorrectionLevel: 'M',
    mode: 'Byte'
  },

  dotsOptions: {
    type: 'square',
    color: '#101A35'
  },

  cornersSquareOptions: {
    type: 'square',
    color: '#101A35'
  },

  cornersDotOptions: {
    type: 'square',
    color: '#101A35'
  },

  backgroundOptions: {
    color: '#FFFFFF'
  },

  imageOptions: {
    hideBackgroundDots: true,
    imageSize: 0,
    margin: 0
  }
};


function StyledQr({ value, size = 176, dark = '#0B1736' }) {
  const box = useRef(null)
  const qr = useRef(null)
  useEffect(() => {
    if (!box.current || !value) return
    const opts = {
      ...QR_LOOK, width: size, height: size, data: String(value),
      dotsOptions: { ...QR_LOOK.dotsOptions, color: dark },
      cornersSquareOptions: { ...QR_LOOK.cornersSquareOptions, color: dark },
      cornersDotOptions: { ...QR_LOOK.cornersDotOptions, color: dark }
    }
    if (!qr.current) { qr.current = new QRCodeStyling(opts); qr.current.append(box.current) }
    else qr.current.update(opts)
  }, [value, size, dark])
  return <div className="qrbox" ref={box} style={{ width: size, height: size }} />
}

async function qrPngBlob(value, { size = 1024, dark = '#0B1736' } = {}) {
  const inst = new QRCodeStyling({
    ...QR_LOOK, type: 'canvas', width: size, height: size, data: String(value),
    dotsOptions: { ...QR_LOOK.dotsOptions, color: dark },
    cornersSquareOptions: { ...QR_LOOK.cornersSquareOptions, color: dark },
    cornersDotOptions: { ...QR_LOOK.cornersDotOptions, color: dark }
  })
  return inst.getRawData('png')
}

const EMPTY = {
  permitId: '', permitNo: '', title: 'تصريح أجير – تعاقد أجير',
  workerName: '', idNumber: '', profession: '', nationality: '', birthDate: '',
  providerCompany: '', providerCr: '', beneficiaryCompany: '', beneficiaryCr: '',
  contractNote: '', startDate: '', endDate: '', workSites: ''
}

const FIELDS = [
  ['permitNo', 'رقم التصريح', 'ltr'],
  ['workerName', 'اسم العامل', 'ltr'],
  ['idNumber', 'رقم الهوية / الإقامة', 'ltr'],
  ['profession', 'المهنة', 'rtl'],
  ['nationality', 'الجنسية', 'rtl'],
  ['providerCompany', 'المنشأة', 'rtl'],
  ['providerCr', 'السجل التجاري', 'ltr'],
  ['beneficiaryCompany', 'المستفيد', 'rtl'],
  ['beneficiaryCr', 'س.ت المستفيد', 'ltr'],
  ['startDate', 'تاريخ البداية', 'ltr'],
  ['endDate', 'تاريخ النهاية', 'ltr'],
  ['workSites', 'مواقع العمل', 'rtl'],
  ['contractNote', 'ملاحظة العقد', 'ltr'],
  ['birthDate', 'تاريخ الميلاد', 'ltr']
]

const statusOf = (p) => {
  const n = new Date()
  if (p.startDate && n < new Date(p.startDate)) return { k: 'pending', ar: 'لم يبدأ بعد' }
  if (p.endDate && n > new Date(p.endDate)) return { k: 'expired', ar: 'منتهي' }
  return { k: 'active', ar: 'ساري / فعال' }
}

export default function App() {
  const [tab, setTab] = useState('new')
  const [form, setForm] = useState(EMPTY)
  const [record, setRecord] = useState(null)     // mongo doc returned by backend
  const [settings, setSettings] = useState({ publicBaseUrl: '' })
  const [items, setItems] = useState([])
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState('')
  const [err, setErr] = useState('')
  const [ink, setInk] = useState('#0B1736')
  const [dom, setDom] = useState('')

  const flash = (m) => { setNote(m); setTimeout(() => setNote(''), 4500) }

  const loadSettings = useCallback(async () => {
    try { const s = await getSettings(); setSettings(s); setDom(s.publicBaseUrl || '') }
    catch (e) { setErr('Settings: ' + e.message) }
  }, [])

  const loadList = useCallback(async (term = '') => {
    try { const r = await listRecords(term); setItems(r.items || []) }
    catch (e) { setErr('List: ' + e.message) }
  }, [])

  /* form pehle se bhara hua ho — MongoDB ka mojooda record khud load ho jata hai */
  const prefill = useCallback(async () => {
    const want = String(import.meta.env.VITE_DEFAULT_ID || 'b283254a').toLowerCase()
    try {
      const r = await getRecord(want)
      setRecord(r.permit); setForm({ ...EMPTY, ...r.permit }); return
    } catch { /* record nahi mila — pehla item try karo */ }
    try {
      const l = await listRecords('')
      const first = l.items?.[0]
      if (first?.permitId) {
        const r = await getRecord(first.permitId)
        setRecord(r.permit); setForm({ ...EMPTY, ...r.permit })
      }
    } catch { /* khali form hi rahe */ }
  }, [])

  useEffect(() => { loadSettings(); loadList(); prefill() }, [loadSettings, loadList, prefill])
  useEffect(() => { if (tab === 'list') loadList(q) }, [tab, q, loadList])

  const st = statusOf({ ...EMPTY, ...form, ...(record || {}) })
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))

  const qrTarget = useMemo(() => {
    if (record?.qrTarget) return record.qrTarget
    const base = settings.publicBaseUrl || (API || window.location.origin)
    return `${base}/v/${form.permitId || form.permitNo || 'preview'}`
  }, [record, settings.publicBaseUrl, form.permitId, form.permitNo])

  const save = async () => {
    setBusy(true); setErr('')
    try {
      const payload = { ...form, permitId: form.permitId || undefined }
      const res = record
        ? await updateRecord(record.permitId, payload)
        : await saveRecord(payload)
      setRecord(res.permit)
      setForm({ ...EMPTY, ...res.permit })
      flash(record ? 'MongoDB میں اپڈیٹ ہو گیا ✓' : 'MongoDB میں محفوظ ہو گیا ✓ — QR بن گیا')
      loadList(q)
    } catch (e) { setErr(e.message) }
    setBusy(false)
  }

  const openRecord = async (id) => {
    setBusy(true); setErr('')
    try {
      const r = await getRecord(id)
      setRecord(r.permit)
      setForm({ ...EMPTY, ...r.permit })
      setTab('new')
      flash('ریکارڈ لوڈ ہو گیا: ' + id)
    } catch (e) { setErr(e.message) }
    setBusy(false)
  }

  const downloadQr = async () => {
    try {
      const blob = await qrPngBlob(qrTarget, { size: 1024, dark: ink })
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `qr-${record?.permitId || 'permit'}.png`
      a.click(); URL.revokeObjectURL(a.href)
      flash('1024px PNG ڈاؤن لوڈ ✓')
    } catch (e) { setErr(e.message) }
  }

  const copyUrl = async () => {
    try { await navigator.clipboard.writeText(qrTarget); flash('URL کاپی ہو گیا ✓') }
    catch { setErr('clipboard blocked') }
  }

  const applyDomain = async () => {
    setBusy(true); setErr('')
    try {
      const r = await setDomain(dom)
      setSettings({ publicBaseUrl: r.publicBaseUrl })
      flash(`ڈومین محفوظ ✓ — ${r.report?.updated ?? 0} QR دوبارہ بنے`)
      loadList(q)
    } catch (e) { setErr(e.message) }
    setBusy(false)
  }

  return (
    <div className="app" dir="rtl">
      <header className="top">
        <div className="brand">
          <span className="mark" />
          <div>
            <h1 className="urdu">اجازت نامہ — MongoDB + QR</h1>
            <p className="ltr">Express · Mongoose · QR = backend URL + id</p>
          </div>
        </div>
        <div className="pill">{record ? 'لوڈ شدہ · ' + record.permitId : 'نیا اندراج'}</div>
      </header>

      <nav className="tabs">
        {[['new', 'نیا اندراج / فارم'], ['list', 'ریکارڈز (MongoDB)'], ['domain', 'ڈومین اور QR']].map(([k, l]) => (
          <button key={k} className={'tab' + (tab === k ? ' tab--on' : '')} onClick={() => setTab(k)}>{l}</button>
        ))}
      </nav>

      {err && <div className="errbar urdu-text">خرابی: {err}</div>}
      {note && <div className="notebar urdu-text">{note}</div>}

      {tab === 'new' && (
        <main className="grid">
          <section className="card">
            <h2 className="urdu">فارم بھریں</h2>
            <p className="hint urdu-text">
              فارم خود بخود MongoDB سے بھر جاتا ہے۔ محفوظ کرنے پر ریکارڈ اسی id کے ساتھ اپڈیٹ ہوتا ہے اور QR بنتا ہے۔
              QR میں صرف بیک اینڈ کا URL + id ہوتا ہے — ڈومین بدلا تو QR دوبارہ بنتا ہے، id وہی رہتا ہے۔
            </p>

            <div className="fields">
              <label className="fld">
                <span className="fld__lb urdu-text">ID (خالی چھوڑیں تو خود بنے گا)</span>
                <div className="inkrow">
                  <input value={form.permitId} dir="ltr" placeholder="abc12345"
                         onChange={(e) => set('permitId', e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))} />
                  <button className="btn btn--ghost" type="button" onClick={() => set('permitId', nowId())}>خود</button>
                </div>
              </label>

              {FIELDS.map(([k, label, dir]) => (
                <label className="fld" key={k}>
                  <span className="fld__lb urdu-text">{label}</span>
                  <input value={form[k] ?? ''} dir={dir} onChange={(e) => set(k, e.target.value)} />
                </label>
              ))}

              <label className="fld">
                <span className="fld__lb urdu-text">QR کا رنگ</span>
                <div className="inkrow">
                  <input className="inkpick" type="color" value={ink} onChange={(e) => setInk(e.target.value)} />
                  <input value={ink} dir="ltr" onChange={(e) => setInk(e.target.value)} />
                </div>
              </label>
            </div>

            <div className="acts">
              <button className="btn" onClick={save} disabled={busy}>{record ? 'اپڈیٹ کریں' : 'محفوظ کریں + QR'}</button>
              {record && <button className="btn btn--ghost" onClick={() => { setRecord(null); setForm(EMPTY) }}>نیا</button>}
              <button className="btn btn--ghost" onClick={downloadQr} disabled={!record}>QR PNG</button>
            </div>
          </section>

          <section className="prevwrap">
            <div className="prevhd urdu-text">پری ویو — یہی ڈیزائن مونگو ڈیٹا کے ساتھ</div>
            <article className="sheet">
              <div className="sheet__brand">
                <div className="sheet__logo">أجير</div>
                <div className="sheet__t">
                  <strong>{form.title || EMPTY.title}</strong>
                  <span>منصة أجير — التحقق من التصريح</span>
                </div>
                <div className={`st st--${st.k}`}>{st.ar}</div>
              </div>

              <div className="sheet__band">بيانات التصريح</div>
              <table className="tbl"><tbody>
                <tr><th>رقم التصريح</th><td>{form.permitNo || '—'}</td><th>نوع التصريح</th><td>{form.title}</td></tr>
                <tr><th>تاريخ البداية</th><td>{form.startDate || '—'}</td><th>تاريخ النهاية</th><td>{form.endDate || '—'}</td></tr>
              </tbody></table>

              <div className="sheet__band">بيانات العامل</div>
              <table className="tbl"><tbody>
                <tr><th>اسم العامل</th><td className="ltr">{form.workerName || '—'}</td><th>رقم الهوية</th><td className="ltr">{form.idNumber || '—'}</td></tr>
                <tr><th>المهنة</th><td>{form.profession || '—'}</td><th>الجنسية</th><td>{form.nationality || '—'}</td></tr>
              </tbody></table>

              <div className="sheet__band">بيانات المنشأة</div>
              <table className="tbl"><tbody>
                <tr><th>المنشأة</th><td>{form.providerCompany || '—'}</td><th>السجل التجاري</th><td className="ltr">{form.providerCr || '—'}</td></tr>
                <tr><th>المستفيد</th><td>{form.beneficiaryCompany || '—'}</td><th>س.ت المستفيد</th><td className="ltr">{form.beneficiaryCr || '—'}</td></tr>
                <tr><th>ملاحظة</th><td colSpan={3} className="ltr">{form.contractNote || '—'}</td></tr>
                <tr><th>مواقع العمل</th><td colSpan={3}>{form.workSites || '—'}</td></tr>
              </tbody></table>

              <div className="sheet__foot">
                <div className="qrside">
                  <StyledQr value={qrTarget} size={168} dark={ink} />
                  <div className="qrhint">امسح الرمز للتحقق</div>
                </div>
                <div className="urlside">
                  <span className="urdu-text">QR میں یہ URL ہے</span>
                  <code>{qrTarget}</code>
                  <div className="idrow">
                    <span className="idchip">ID: <b dir="ltr">{record?.permitId || form.permitId || '—'}</b></span>
                    <button className="mini" onClick={copyUrl}>URL کاپی</button>
                    {record && (
                      <a className="mini" href={qrTarget} target="_blank" rel="noreferrer">اسکین پیج کھولیں</a>
                    )}
                  </div>
                  <small className="urdu-text">
                    ڈیٹا MongoDB سے آ رہا ہے — کسی بھی وقت بدلا جا سکتا ہے، QR وہی رہتا ہے۔
                  </small>
                </div>
              </div>
            </article>
          </section>
        </main>
      )}

      {tab === 'list' && (
        <main className="wide">
          <div className="listbar">
            <input placeholder="رقم التصريح / نام / ID تلاش کریں" value={q}
                   dir="rtl" onChange={(e) => setQ(e.target.value)} className="search" />
            <button className="btn btn--ghost" onClick={() => loadList(q)} disabled={busy}>ریفریش</button>
            <span className="count urdu-text">{items.length} ریکارڈ</span>
          </div>

          {items.length === 0 ? (
            <div className="empty urdu-text">کوئی ریکارڈ نہیں — پہلے فارم سے ایک محفوظ کریں۔</div>
          ) : (
            <div className="reclist">
              {items.map((it) => (
                <div className="rec" key={it.permitId}>
                  <img className="rec__qr" src={`${API}/qr/${it.permitId}.png`} alt={'QR ' + it.permitId} />
                  <div className="rec__body">
                    <div className="rec__top">
                      <strong className="ltr">{it.permitNo || it.permitId}</strong>
                      <span className="badge">{statusOf(it).ar}</span>
                    </div>
                    <div className="rec__name ltr">{it.workerName || '—'}</div>
                    <div className="rec__meta ltr">ID {it.idNumber || '—'} · {it.startDate || '—'} → {it.endDate || '—'}</div>
                    <div className="rec__url ltr">{it.qr?.targetUrl || `${settings.publicBaseUrl}/v/${it.permitId}`}</div>
                  </div>
                  <div className="rec__acts">
                    <button className="mini" onClick={() => openRecord(it.permitId)}>کھولیں</button>
                    <a className="mini" href={`${API}/qr/${it.permitId}.png`} target="_blank" rel="noreferrer">QR</a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      )}

      {tab === 'domain' && (
        <main className="wide">
          <section className="card">
            <h2 className="urdu">ڈومین / QR بیس URL</h2>
            <p className="hint urdu-text">
              یہ وہی host ہے جو QR کے اندر لکھا جاتا ہے (<code className="ltr">BASE/v/&lt;id&gt;</code>)۔
              یہ MongoDB کے <code className="ltr">UrlConfig</code> میں محفوظ رہتا ہے۔ بدلنے پر سارے QR
              نئے ڈومین کے ساتھ دوبارہ بنتے ہیں، id اور ڈیٹا وہی رہتا ہے۔
            </p>

            <div className="domrow">
              <label className="fld">
                <span className="fld__lb urdu-text">موجودہ بیس URL</span>
                <input value={settings.publicBaseUrl} dir="ltr" readOnly />
              </label>
              <label className="fld">
                <span className="fld__lb urdu-text">نیا بیس URL</span>
                <input value={dom} dir="ltr" placeholder="https://api.nayadomain.com" onChange={(e) => setDom(e.target.value)} />
              </label>
            </div>
            <div className="acts">
              <button className="btn" onClick={applyDomain} disabled={busy || !dom}>محفوظ + QR ری جنریٹ</button>
            </div>
            <p className="warnbox urdu-text">
              نوٹ: QR میں host لکھا ہوتا ہے، اس لیے جو QR پرنٹ ہو چکا ہے وہ پرانے host پر ہی جائے گا۔
              پرانا ڈومین زندہ رکھیں اور <code className="ltr">/v/:id</code> کو نئے ڈومین پر redirect کر دیں،
              ورنہ ہر تبدیلی پر QR دوبارہ پرنٹ کرنا پڑے گا۔
            </p>
          </section>
        </main>
      )}
    </div>
  )
}
